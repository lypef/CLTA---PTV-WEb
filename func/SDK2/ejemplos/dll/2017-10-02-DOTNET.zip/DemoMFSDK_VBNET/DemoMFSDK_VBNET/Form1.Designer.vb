﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.msPrincipal = New System.Windows.Forms.MenuStrip()
        Me.ejemplosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.facturaNormalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.nómina12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiNomina12Normal = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiAccionesTitulos = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiFiniquito = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiGobierno = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiHorasExtra = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiIncapacidad = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiJubilacion = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSubContratacion = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiSubsidio = New System.Windows.Forms.ToolStripMenuItem()
        Me.escuelaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.parcialidadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.arrendamientoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.chequeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cancelarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.notarioPublicoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.doralesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.hotelesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tercerosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.impuestosLocalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.comercioExteriorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiINE = New System.Windows.Forms.ToolStripMenuItem()
        Me.cancelarConAcuseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.consultarSaldoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.timbrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.treeView1 = New System.Windows.Forms.TreeView()
        Me.tabControl1 = New System.Windows.Forms.TabControl()
        Me.tabPage1 = New System.Windows.Forms.TabPage()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.tabPage2 = New System.Windows.Forms.TabPage()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.OtroComplementoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Factura32ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.msPrincipal.SuspendLayout()
        Me.tabControl1.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.tabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'msPrincipal
        '
        Me.msPrincipal.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ejemplosToolStripMenuItem, Me.timbrarToolStripMenuItem})
        Me.msPrincipal.Location = New System.Drawing.Point(0, 0)
        Me.msPrincipal.Name = "msPrincipal"
        Me.msPrincipal.Size = New System.Drawing.Size(828, 24)
        Me.msPrincipal.TabIndex = 3
        Me.msPrincipal.Text = "menuStrip1"
        '
        'ejemplosToolStripMenuItem
        '
        Me.ejemplosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.facturaNormalToolStripMenuItem, Me.nómina12ToolStripMenuItem, Me.escuelaToolStripMenuItem, Me.parcialidadToolStripMenuItem, Me.arrendamientoToolStripMenuItem, Me.chequeToolStripMenuItem, Me.cancelarToolStripMenuItem, Me.notarioPublicoToolStripMenuItem, Me.doralesToolStripMenuItem, Me.hotelesToolStripMenuItem, Me.tercerosToolStripMenuItem, Me.impuestosLocalesToolStripMenuItem, Me.comercioExteriorToolStripMenuItem, Me.tsmiINE, Me.cancelarConAcuseToolStripMenuItem, Me.toolStripSeparator1, Me.consultarSaldoToolStripMenuItem, Me.OtroComplementoToolStripMenuItem, Me.Factura32ToolStripMenuItem})
        Me.ejemplosToolStripMenuItem.Name = "ejemplosToolStripMenuItem"
        Me.ejemplosToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.ejemplosToolStripMenuItem.Text = "&Ejemplos"
        '
        'facturaNormalToolStripMenuItem
        '
        Me.facturaNormalToolStripMenuItem.Name = "facturaNormalToolStripMenuItem"
        Me.facturaNormalToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.facturaNormalToolStripMenuItem.Text = "Factura Normal"
        '
        'nómina12ToolStripMenuItem
        '
        Me.nómina12ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiNomina12Normal, Me.tsmiAccionesTitulos, Me.tsmiFiniquito, Me.tsmiGobierno, Me.tsmiHorasExtra, Me.tsmiIncapacidad, Me.tsmiJubilacion, Me.tsmiSubContratacion, Me.tsmiSubsidio})
        Me.nómina12ToolStripMenuItem.Name = "nómina12ToolStripMenuItem"
        Me.nómina12ToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.nómina12ToolStripMenuItem.Text = "Nómina 1.2"
        '
        'tsmiNomina12Normal
        '
        Me.tsmiNomina12Normal.Name = "tsmiNomina12Normal"
        Me.tsmiNomina12Normal.Size = New System.Drawing.Size(171, 22)
        Me.tsmiNomina12Normal.Text = "Normal"
        '
        'tsmiAccionesTitulos
        '
        Me.tsmiAccionesTitulos.Name = "tsmiAccionesTitulos"
        Me.tsmiAccionesTitulos.Size = New System.Drawing.Size(171, 22)
        Me.tsmiAccionesTitulos.Text = "Acciones o Titulos"
        '
        'tsmiFiniquito
        '
        Me.tsmiFiniquito.Name = "tsmiFiniquito"
        Me.tsmiFiniquito.Size = New System.Drawing.Size(171, 22)
        Me.tsmiFiniquito.Text = "Finiquito"
        '
        'tsmiGobierno
        '
        Me.tsmiGobierno.Name = "tsmiGobierno"
        Me.tsmiGobierno.Size = New System.Drawing.Size(171, 22)
        Me.tsmiGobierno.Text = "Gobierno"
        '
        'tsmiHorasExtra
        '
        Me.tsmiHorasExtra.Name = "tsmiHorasExtra"
        Me.tsmiHorasExtra.Size = New System.Drawing.Size(171, 22)
        Me.tsmiHorasExtra.Text = "Horas Extra"
        '
        'tsmiIncapacidad
        '
        Me.tsmiIncapacidad.Name = "tsmiIncapacidad"
        Me.tsmiIncapacidad.Size = New System.Drawing.Size(171, 22)
        Me.tsmiIncapacidad.Text = "Incapacidad"
        '
        'tsmiJubilacion
        '
        Me.tsmiJubilacion.Name = "tsmiJubilacion"
        Me.tsmiJubilacion.Size = New System.Drawing.Size(171, 22)
        Me.tsmiJubilacion.Text = "Jubilacion"
        '
        'tsmiSubContratacion
        '
        Me.tsmiSubContratacion.Name = "tsmiSubContratacion"
        Me.tsmiSubContratacion.Size = New System.Drawing.Size(171, 22)
        Me.tsmiSubContratacion.Text = "Sub Contratacion"
        '
        'tsmiSubsidio
        '
        Me.tsmiSubsidio.Name = "tsmiSubsidio"
        Me.tsmiSubsidio.Size = New System.Drawing.Size(171, 22)
        Me.tsmiSubsidio.Text = "Subsidio"
        '
        'escuelaToolStripMenuItem
        '
        Me.escuelaToolStripMenuItem.Name = "escuelaToolStripMenuItem"
        Me.escuelaToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.escuelaToolStripMenuItem.Text = "Escuela"
        '
        'parcialidadToolStripMenuItem
        '
        Me.parcialidadToolStripMenuItem.Name = "parcialidadToolStripMenuItem"
        Me.parcialidadToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.parcialidadToolStripMenuItem.Text = "Parcialidad"
        '
        'arrendamientoToolStripMenuItem
        '
        Me.arrendamientoToolStripMenuItem.Name = "arrendamientoToolStripMenuItem"
        Me.arrendamientoToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.arrendamientoToolStripMenuItem.Text = "Arrendamiento"
        '
        'chequeToolStripMenuItem
        '
        Me.chequeToolStripMenuItem.Name = "chequeToolStripMenuItem"
        Me.chequeToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.chequeToolStripMenuItem.Text = "Cheque"
        '
        'cancelarToolStripMenuItem
        '
        Me.cancelarToolStripMenuItem.Name = "cancelarToolStripMenuItem"
        Me.cancelarToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.cancelarToolStripMenuItem.Text = "Cancelar"
        '
        'notarioPublicoToolStripMenuItem
        '
        Me.notarioPublicoToolStripMenuItem.Name = "notarioPublicoToolStripMenuItem"
        Me.notarioPublicoToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.notarioPublicoToolStripMenuItem.Text = "Notario Publico"
        '
        'doralesToolStripMenuItem
        '
        Me.doralesToolStripMenuItem.Name = "doralesToolStripMenuItem"
        Me.doralesToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.doralesToolStripMenuItem.Text = "Dolares"
        '
        'hotelesToolStripMenuItem
        '
        Me.hotelesToolStripMenuItem.Name = "hotelesToolStripMenuItem"
        Me.hotelesToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.hotelesToolStripMenuItem.Text = "Hoteles"
        '
        'tercerosToolStripMenuItem
        '
        Me.tercerosToolStripMenuItem.Name = "tercerosToolStripMenuItem"
        Me.tercerosToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.tercerosToolStripMenuItem.Text = "Terceros"
        '
        'impuestosLocalesToolStripMenuItem
        '
        Me.impuestosLocalesToolStripMenuItem.Name = "impuestosLocalesToolStripMenuItem"
        Me.impuestosLocalesToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.impuestosLocalesToolStripMenuItem.Text = "Impuestos Locales"
        '
        'comercioExteriorToolStripMenuItem
        '
        Me.comercioExteriorToolStripMenuItem.Name = "comercioExteriorToolStripMenuItem"
        Me.comercioExteriorToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.comercioExteriorToolStripMenuItem.Text = "Comercio Exterior"
        '
        'tsmiINE
        '
        Me.tsmiINE.Name = "tsmiINE"
        Me.tsmiINE.Size = New System.Drawing.Size(175, 22)
        Me.tsmiINE.Text = "INE"
        '
        'cancelarConAcuseToolStripMenuItem
        '
        Me.cancelarConAcuseToolStripMenuItem.Name = "cancelarConAcuseToolStripMenuItem"
        Me.cancelarConAcuseToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.cancelarConAcuseToolStripMenuItem.Text = "Pagos"
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(172, 6)
        '
        'consultarSaldoToolStripMenuItem
        '
        Me.consultarSaldoToolStripMenuItem.Name = "consultarSaldoToolStripMenuItem"
        Me.consultarSaldoToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.consultarSaldoToolStripMenuItem.Text = "&Consultar Saldo"
        '
        'timbrarToolStripMenuItem
        '
        Me.timbrarToolStripMenuItem.Name = "timbrarToolStripMenuItem"
        Me.timbrarToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.timbrarToolStripMenuItem.Text = "&Timbrar"
        '
        'treeView1
        '
        Me.treeView1.Location = New System.Drawing.Point(12, 27)
        Me.treeView1.Name = "treeView1"
        Me.treeView1.Size = New System.Drawing.Size(370, 463)
        Me.treeView1.TabIndex = 6
        '
        'tabControl1
        '
        Me.tabControl1.Controls.Add(Me.tabPage1)
        Me.tabControl1.Controls.Add(Me.tabPage2)
        Me.tabControl1.Location = New System.Drawing.Point(388, 27)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(437, 463)
        Me.tabControl1.TabIndex = 7
        '
        'tabPage1
        '
        Me.tabPage1.Controls.Add(Me.textBox1)
        Me.tabPage1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage1.Size = New System.Drawing.Size(429, 437)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "Ini Factura"
        Me.tabPage1.UseVisualStyleBackColor = True
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(3, 6)
        Me.textBox1.Multiline = True
        Me.textBox1.Name = "textBox1"
        Me.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.textBox1.Size = New System.Drawing.Size(420, 428)
        Me.textBox1.TabIndex = 2
        '
        'tabPage2
        '
        Me.tabPage2.Controls.Add(Me.textBox2)
        Me.tabPage2.Location = New System.Drawing.Point(4, 22)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage2.Size = New System.Drawing.Size(429, 437)
        Me.tabPage2.TabIndex = 1
        Me.tabPage2.Text = "Respuesta Ini"
        Me.tabPage2.UseVisualStyleBackColor = True
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(6, 3)
        Me.textBox2.Multiline = True
        Me.textBox2.Name = "textBox2"
        Me.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.textBox2.Size = New System.Drawing.Size(417, 428)
        Me.textBox2.TabIndex = 5
        '
        'OtroComplementoToolStripMenuItem
        '
        Me.OtroComplementoToolStripMenuItem.Name = "OtroComplementoToolStripMenuItem"
        Me.OtroComplementoToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.OtroComplementoToolStripMenuItem.Text = "OtroComplemento"
        '
        'Factura32ToolStripMenuItem
        '
        Me.Factura32ToolStripMenuItem.Name = "Factura32ToolStripMenuItem"
        Me.Factura32ToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.Factura32ToolStripMenuItem.Text = "Factura 3.2"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(828, 491)
        Me.Controls.Add(Me.tabControl1)
        Me.Controls.Add(Me.treeView1)
        Me.Controls.Add(Me.msPrincipal)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.msPrincipal.ResumeLayout(False)
        Me.msPrincipal.PerformLayout()
        Me.tabControl1.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.tabPage1.PerformLayout()
        Me.tabPage2.ResumeLayout(False)
        Me.tabPage2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents msPrincipal As MenuStrip
    Private WithEvents ejemplosToolStripMenuItem As ToolStripMenuItem
    Private WithEvents facturaNormalToolStripMenuItem As ToolStripMenuItem
    Private WithEvents nómina12ToolStripMenuItem As ToolStripMenuItem
    Private WithEvents tsmiNomina12Normal As ToolStripMenuItem
    Private WithEvents tsmiAccionesTitulos As ToolStripMenuItem
    Private WithEvents tsmiFiniquito As ToolStripMenuItem
    Private WithEvents tsmiGobierno As ToolStripMenuItem
    Private WithEvents tsmiHorasExtra As ToolStripMenuItem
    Private WithEvents tsmiIncapacidad As ToolStripMenuItem
    Private WithEvents tsmiJubilacion As ToolStripMenuItem
    Private WithEvents tsmiSubContratacion As ToolStripMenuItem
    Private WithEvents tsmiSubsidio As ToolStripMenuItem
    Private WithEvents escuelaToolStripMenuItem As ToolStripMenuItem
    Private WithEvents parcialidadToolStripMenuItem As ToolStripMenuItem
    Private WithEvents arrendamientoToolStripMenuItem As ToolStripMenuItem
    Private WithEvents chequeToolStripMenuItem As ToolStripMenuItem
    Private WithEvents cancelarToolStripMenuItem As ToolStripMenuItem
    Private WithEvents notarioPublicoToolStripMenuItem As ToolStripMenuItem
    Private WithEvents doralesToolStripMenuItem As ToolStripMenuItem
    Private WithEvents hotelesToolStripMenuItem As ToolStripMenuItem
    Private WithEvents tercerosToolStripMenuItem As ToolStripMenuItem
    Private WithEvents impuestosLocalesToolStripMenuItem As ToolStripMenuItem
    Private WithEvents comercioExteriorToolStripMenuItem As ToolStripMenuItem
    Private WithEvents tsmiINE As ToolStripMenuItem
    Private WithEvents cancelarConAcuseToolStripMenuItem As ToolStripMenuItem
    Private WithEvents toolStripSeparator1 As ToolStripSeparator
    Private WithEvents consultarSaldoToolStripMenuItem As ToolStripMenuItem
    Private WithEvents timbrarToolStripMenuItem As ToolStripMenuItem
    Private WithEvents treeView1 As TreeView
    Private WithEvents tabControl1 As TabControl
    Private WithEvents tabPage1 As TabPage
    Private WithEvents textBox1 As TextBox
    Private WithEvents tabPage2 As TabPage
    Private WithEvents textBox2 As TextBox
    Friend WithEvents OtroComplementoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Factura32ToolStripMenuItem As ToolStripMenuItem
End Class

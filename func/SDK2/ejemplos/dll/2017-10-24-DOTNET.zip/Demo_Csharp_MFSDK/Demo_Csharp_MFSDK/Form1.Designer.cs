﻿namespace Demo_Csharp_MFSDK
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.msPrincipal = new System.Windows.Forms.MenuStrip();
            this.ejemplosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facturaNormalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nómina12ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNomina12Normal = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAccionesTitulos = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiFiniquito = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiGobierno = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiHorasExtra = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiIncapacidad = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiJubilacion = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSubContratacion = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSubsidio = new System.Windows.Forms.ToolStripMenuItem();
            this.escuelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parcialidadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arrendamientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chequeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notarioPublicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doralesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hotelesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tercerosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impuestosLocalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comercioExteriorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiINE = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelarConAcuseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.consultarSaldoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otroComplementoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.factura32ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timbrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.msPrincipal.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // msPrincipal
            // 
            this.msPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ejemplosToolStripMenuItem,
            this.timbrarToolStripMenuItem});
            this.msPrincipal.Location = new System.Drawing.Point(0, 0);
            this.msPrincipal.Name = "msPrincipal";
            this.msPrincipal.Size = new System.Drawing.Size(831, 24);
            this.msPrincipal.TabIndex = 3;
            this.msPrincipal.Text = "menuStrip1";
            // 
            // ejemplosToolStripMenuItem
            // 
            this.ejemplosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.facturaNormalToolStripMenuItem,
            this.nómina12ToolStripMenuItem,
            this.escuelaToolStripMenuItem,
            this.parcialidadToolStripMenuItem,
            this.arrendamientoToolStripMenuItem,
            this.chequeToolStripMenuItem,
            this.cancelarToolStripMenuItem,
            this.notarioPublicoToolStripMenuItem,
            this.doralesToolStripMenuItem,
            this.hotelesToolStripMenuItem,
            this.tercerosToolStripMenuItem,
            this.impuestosLocalesToolStripMenuItem,
            this.comercioExteriorToolStripMenuItem,
            this.tsmiINE,
            this.cancelarConAcuseToolStripMenuItem,
            this.toolStripSeparator1,
            this.consultarSaldoToolStripMenuItem,
            this.otroComplementoToolStripMenuItem,
            this.factura32ToolStripMenuItem});
            this.ejemplosToolStripMenuItem.Name = "ejemplosToolStripMenuItem";
            this.ejemplosToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.ejemplosToolStripMenuItem.Text = "&Ejemplos";
            this.ejemplosToolStripMenuItem.Click += new System.EventHandler(this.ejemplosToolStripMenuItem_Click);
            // 
            // facturaNormalToolStripMenuItem
            // 
            this.facturaNormalToolStripMenuItem.Name = "facturaNormalToolStripMenuItem";
            this.facturaNormalToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.facturaNormalToolStripMenuItem.Text = "Factura Normal";
            this.facturaNormalToolStripMenuItem.Click += new System.EventHandler(this.facturaNormalToolStripMenuItem_Click);
            // 
            // nómina12ToolStripMenuItem
            // 
            this.nómina12ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiNomina12Normal,
            this.tsmiAccionesTitulos,
            this.tsmiFiniquito,
            this.tsmiGobierno,
            this.tsmiHorasExtra,
            this.tsmiIncapacidad,
            this.tsmiJubilacion,
            this.tsmiSubContratacion,
            this.tsmiSubsidio});
            this.nómina12ToolStripMenuItem.Name = "nómina12ToolStripMenuItem";
            this.nómina12ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.nómina12ToolStripMenuItem.Text = "Nómina 1.2";
            // 
            // tsmiNomina12Normal
            // 
            this.tsmiNomina12Normal.Name = "tsmiNomina12Normal";
            this.tsmiNomina12Normal.Size = new System.Drawing.Size(171, 22);
            this.tsmiNomina12Normal.Text = "Normal";
            this.tsmiNomina12Normal.Click += new System.EventHandler(this.tsmiNomina12Normal_Click);
            // 
            // tsmiAccionesTitulos
            // 
            this.tsmiAccionesTitulos.Name = "tsmiAccionesTitulos";
            this.tsmiAccionesTitulos.Size = new System.Drawing.Size(171, 22);
            this.tsmiAccionesTitulos.Text = "Acciones o Titulos";
            this.tsmiAccionesTitulos.Click += new System.EventHandler(this.tsmiAccionesTitulos_Click);
            // 
            // tsmiFiniquito
            // 
            this.tsmiFiniquito.Name = "tsmiFiniquito";
            this.tsmiFiniquito.Size = new System.Drawing.Size(171, 22);
            this.tsmiFiniquito.Text = "Finiquito";
            this.tsmiFiniquito.Click += new System.EventHandler(this.tsmiFiniquito_Click);
            // 
            // tsmiGobierno
            // 
            this.tsmiGobierno.Name = "tsmiGobierno";
            this.tsmiGobierno.Size = new System.Drawing.Size(171, 22);
            this.tsmiGobierno.Text = "Gobierno";
            this.tsmiGobierno.Click += new System.EventHandler(this.tsmiGobierno_Click);
            // 
            // tsmiHorasExtra
            // 
            this.tsmiHorasExtra.Name = "tsmiHorasExtra";
            this.tsmiHorasExtra.Size = new System.Drawing.Size(171, 22);
            this.tsmiHorasExtra.Text = "Horas Extra";
            this.tsmiHorasExtra.Click += new System.EventHandler(this.tsmiHorasExtra_Click);
            // 
            // tsmiIncapacidad
            // 
            this.tsmiIncapacidad.Name = "tsmiIncapacidad";
            this.tsmiIncapacidad.Size = new System.Drawing.Size(171, 22);
            this.tsmiIncapacidad.Text = "Incapacidad";
            this.tsmiIncapacidad.Click += new System.EventHandler(this.tsmiIncapacidad_Click);
            // 
            // tsmiJubilacion
            // 
            this.tsmiJubilacion.Name = "tsmiJubilacion";
            this.tsmiJubilacion.Size = new System.Drawing.Size(171, 22);
            this.tsmiJubilacion.Text = "Jubilacion";
            this.tsmiJubilacion.Click += new System.EventHandler(this.tsmiJubilacion_Click);
            // 
            // tsmiSubContratacion
            // 
            this.tsmiSubContratacion.Name = "tsmiSubContratacion";
            this.tsmiSubContratacion.Size = new System.Drawing.Size(171, 22);
            this.tsmiSubContratacion.Text = "Sub Contratacion";
            this.tsmiSubContratacion.Click += new System.EventHandler(this.tsmiSubContratacion_Click);
            // 
            // tsmiSubsidio
            // 
            this.tsmiSubsidio.Name = "tsmiSubsidio";
            this.tsmiSubsidio.Size = new System.Drawing.Size(171, 22);
            this.tsmiSubsidio.Text = "Subsidio";
            this.tsmiSubsidio.Click += new System.EventHandler(this.tsmiSubsidio_Click);
            // 
            // escuelaToolStripMenuItem
            // 
            this.escuelaToolStripMenuItem.Name = "escuelaToolStripMenuItem";
            this.escuelaToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.escuelaToolStripMenuItem.Text = "Escuela";
            this.escuelaToolStripMenuItem.Click += new System.EventHandler(this.escuelaToolStripMenuItem_Click);
            // 
            // parcialidadToolStripMenuItem
            // 
            this.parcialidadToolStripMenuItem.Name = "parcialidadToolStripMenuItem";
            this.parcialidadToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.parcialidadToolStripMenuItem.Text = "Parcialidad";
            this.parcialidadToolStripMenuItem.Click += new System.EventHandler(this.parcialidadToolStripMenuItem_Click);
            // 
            // arrendamientoToolStripMenuItem
            // 
            this.arrendamientoToolStripMenuItem.Name = "arrendamientoToolStripMenuItem";
            this.arrendamientoToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.arrendamientoToolStripMenuItem.Text = "Arrendamiento";
            this.arrendamientoToolStripMenuItem.Click += new System.EventHandler(this.arrendamientoToolStripMenuItem_Click);
            // 
            // chequeToolStripMenuItem
            // 
            this.chequeToolStripMenuItem.Name = "chequeToolStripMenuItem";
            this.chequeToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.chequeToolStripMenuItem.Text = "Cheque";
            this.chequeToolStripMenuItem.Click += new System.EventHandler(this.chequeToolStripMenuItem_Click);
            // 
            // cancelarToolStripMenuItem
            // 
            this.cancelarToolStripMenuItem.Name = "cancelarToolStripMenuItem";
            this.cancelarToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.cancelarToolStripMenuItem.Text = "Cancelar";
            this.cancelarToolStripMenuItem.Click += new System.EventHandler(this.cancelarToolStripMenuItem_Click);
            // 
            // notarioPublicoToolStripMenuItem
            // 
            this.notarioPublicoToolStripMenuItem.Name = "notarioPublicoToolStripMenuItem";
            this.notarioPublicoToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.notarioPublicoToolStripMenuItem.Text = "Notario Publico";
            this.notarioPublicoToolStripMenuItem.Click += new System.EventHandler(this.notarioPublicoToolStripMenuItem_Click);
            // 
            // doralesToolStripMenuItem
            // 
            this.doralesToolStripMenuItem.Name = "doralesToolStripMenuItem";
            this.doralesToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.doralesToolStripMenuItem.Text = "Dolares";
            this.doralesToolStripMenuItem.Click += new System.EventHandler(this.doralesToolStripMenuItem_Click);
            // 
            // hotelesToolStripMenuItem
            // 
            this.hotelesToolStripMenuItem.Name = "hotelesToolStripMenuItem";
            this.hotelesToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.hotelesToolStripMenuItem.Text = "Hoteles";
            this.hotelesToolStripMenuItem.Click += new System.EventHandler(this.hotelesToolStripMenuItem_Click);
            // 
            // tercerosToolStripMenuItem
            // 
            this.tercerosToolStripMenuItem.Name = "tercerosToolStripMenuItem";
            this.tercerosToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.tercerosToolStripMenuItem.Text = "Terceros";
            this.tercerosToolStripMenuItem.Click += new System.EventHandler(this.tercerosToolStripMenuItem_Click);
            // 
            // impuestosLocalesToolStripMenuItem
            // 
            this.impuestosLocalesToolStripMenuItem.Name = "impuestosLocalesToolStripMenuItem";
            this.impuestosLocalesToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.impuestosLocalesToolStripMenuItem.Text = "Impuestos Locales";
            this.impuestosLocalesToolStripMenuItem.Click += new System.EventHandler(this.impuestosLocalesToolStripMenuItem_Click);
            // 
            // comercioExteriorToolStripMenuItem
            // 
            this.comercioExteriorToolStripMenuItem.Name = "comercioExteriorToolStripMenuItem";
            this.comercioExteriorToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.comercioExteriorToolStripMenuItem.Text = "Comercio Exterior";
            this.comercioExteriorToolStripMenuItem.Click += new System.EventHandler(this.comercioExteriorToolStripMenuItem_Click);
            // 
            // tsmiINE
            // 
            this.tsmiINE.Name = "tsmiINE";
            this.tsmiINE.Size = new System.Drawing.Size(178, 22);
            this.tsmiINE.Text = "INE";
            this.tsmiINE.Click += new System.EventHandler(this.tsmiINE_Click);
            // 
            // cancelarConAcuseToolStripMenuItem
            // 
            this.cancelarConAcuseToolStripMenuItem.Name = "cancelarConAcuseToolStripMenuItem";
            this.cancelarConAcuseToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.cancelarConAcuseToolStripMenuItem.Text = "Pagos";
            this.cancelarConAcuseToolStripMenuItem.Click += new System.EventHandler(this.cancelarConAcuseToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(175, 6);
            // 
            // consultarSaldoToolStripMenuItem
            // 
            this.consultarSaldoToolStripMenuItem.Name = "consultarSaldoToolStripMenuItem";
            this.consultarSaldoToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.consultarSaldoToolStripMenuItem.Text = "&Consultar Saldo";
            this.consultarSaldoToolStripMenuItem.Click += new System.EventHandler(this.consultarSaldoToolStripMenuItem_Click);
            // 
            // otroComplementoToolStripMenuItem
            // 
            this.otroComplementoToolStripMenuItem.Name = "otroComplementoToolStripMenuItem";
            this.otroComplementoToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.otroComplementoToolStripMenuItem.Text = "Otro Complemento";
            this.otroComplementoToolStripMenuItem.Click += new System.EventHandler(this.otroComplementoToolStripMenuItem_Click);
            // 
            // factura32ToolStripMenuItem
            // 
            this.factura32ToolStripMenuItem.Name = "factura32ToolStripMenuItem";
            this.factura32ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.factura32ToolStripMenuItem.Text = "Factura 3.2";
            this.factura32ToolStripMenuItem.Click += new System.EventHandler(this.factura32ToolStripMenuItem_Click);
            // 
            // timbrarToolStripMenuItem
            // 
            this.timbrarToolStripMenuItem.Name = "timbrarToolStripMenuItem";
            this.timbrarToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.timbrarToolStripMenuItem.Text = "&Timbrar";
            this.timbrarToolStripMenuItem.Click += new System.EventHandler(this.timbrarToolStripMenuItem_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(12, 27);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(370, 463);
            this.treeView1.TabIndex = 6;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(388, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(437, 463);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(429, 437);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ini Factura";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 6);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(420, 428);
            this.textBox1.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(429, 437);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Respuesta Ini";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(6, 3);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox2.Size = new System.Drawing.Size(417, 428);
            this.textBox2.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(831, 497);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.msPrincipal);
            this.Name = "Form1";
            this.Text = "Demo C# SDK";
            this.msPrincipal.ResumeLayout(false);
            this.msPrincipal.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msPrincipal;
        private System.Windows.Forms.ToolStripMenuItem ejemplosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facturaNormalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nómina12ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiNomina12Normal;
        private System.Windows.Forms.ToolStripMenuItem tsmiAccionesTitulos;
        private System.Windows.Forms.ToolStripMenuItem tsmiFiniquito;
        private System.Windows.Forms.ToolStripMenuItem tsmiGobierno;
        private System.Windows.Forms.ToolStripMenuItem tsmiHorasExtra;
        private System.Windows.Forms.ToolStripMenuItem tsmiIncapacidad;
        private System.Windows.Forms.ToolStripMenuItem tsmiJubilacion;
        private System.Windows.Forms.ToolStripMenuItem tsmiSubContratacion;
        private System.Windows.Forms.ToolStripMenuItem tsmiSubsidio;
        private System.Windows.Forms.ToolStripMenuItem escuelaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parcialidadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arrendamientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chequeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notarioPublicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doralesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hotelesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tercerosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impuestosLocalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comercioExteriorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiINE;
        private System.Windows.Forms.ToolStripMenuItem cancelarConAcuseToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem consultarSaldoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem timbrarToolStripMenuItem;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ToolStripMenuItem otroComplementoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem factura32ToolStripMenuItem;
    }
}

